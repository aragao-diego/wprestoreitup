-- MySQL dump 10.13  Distrib 5.5.48-37.8, for Linux (x86_64)
--
-- Host: localhost    Database: newprime_wrdp1
-- ------------------------------------------------------
-- Server version	5.5.48-37.8

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `wp_wpgmza`
--

DROP TABLE IF EXISTS `wp_wpgmza`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_wpgmza` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `map_id` int(11) NOT NULL,
  `address` varchar(700) NOT NULL,
  `description` mediumtext NOT NULL,
  `pic` varchar(700) NOT NULL,
  `link` varchar(700) NOT NULL,
  `icon` varchar(700) NOT NULL,
  `lat` varchar(100) NOT NULL,
  `lng` varchar(100) NOT NULL,
  `anim` varchar(3) NOT NULL,
  `title` varchar(700) NOT NULL,
  `infoopen` varchar(3) NOT NULL,
  `category` varchar(500) NOT NULL,
  `approved` tinyint(1) DEFAULT '1',
  `retina` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wpgmza`
--
-- WHERE:  1 LIMIT 0,10000

LOCK TABLES `wp_wpgmza` WRITE;
/*!40000 ALTER TABLE `wp_wpgmza` DISABLE KEYS */;
INSERT  IGNORE INTO `wp_wpgmza` VALUES (2,1,'Rua Moacir José Leite - Jardim Nova America, Divinópolis - MG, Brasil','','','','','-20.127685','-44.88283849999999','1','','0','',1,0),(3,1,'Av. Orcalino Santos, Caldas Novas - GO, Brasil','','','','','-17.7408477','-48.62553300000002','1','','0','',1,0),(4,1,'Av. Perimetral Norte - Setor Goiânia 2, Goiânia - GO, Brasil','','','','','-16.6235219','-49.2467934','1','','0','',1,0),(5,1,'Rua Gonçalves Crespo - Tatuapé, São Paulo - SP, Brasil','','','','','-23.538521','-46.575521','1','','0','',1,0),(6,1,'Avenida Professor Abraão de Morais - Saúde, São Paulo - SP, Brasil','','','','','-23.6188737','-46.62805479999997','1','','0','',1,0),(7,1,'Av. Leopoldino de Oliveira - Estados Unidos, Uberaba - MG, Brasil','','','','','-19.7507568','-47.929072599999984','1','','0','',1,0),(8,1,'Avenida João Naves de Ávila - Centro, Uberlândia - MG, Brasil','','','','','-18.9139179','-48.267720800000006','1','','0','',1,0),(9,1,'Av. Nicomedes Alves dos Santos - Centro, Uberlândia - MG, Brasil','','','','','-18.9269072','-48.27957789999999','1','','0','',1,0);
/*!40000 ALTER TABLE `wp_wpgmza` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-07-06 21:18:15
