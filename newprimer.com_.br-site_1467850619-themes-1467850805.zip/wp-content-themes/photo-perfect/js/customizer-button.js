( function( $ ) {

	// Add Upgrade button.
	$( '.preview-notice' ).prepend( '<span id="btn-wen-upgrade"><a target="_blank" class="button btn-upgrade" href="' + Photo_Perfect_Customizer_Object.updrade_button_link + '">' + Photo_Perfect_Customizer_Object.updrade_button_text + '</a></span>' );

} )( jQuery );
