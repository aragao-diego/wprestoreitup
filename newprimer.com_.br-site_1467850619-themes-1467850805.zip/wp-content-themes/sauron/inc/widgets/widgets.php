<?php
/// include widgets
/// include Advertisement Widget

require_once( 'widget-advert.php' );
/// include Advertisement Widget
require_once( 'widget-adsens.php' );
// incude Category Post
require_once( 'widget-category.php' );
// incude Percent widget
require_once( 'widget-percent.php' );
// incude categories 
require_once( 'widget-categories.php' ); 
?>