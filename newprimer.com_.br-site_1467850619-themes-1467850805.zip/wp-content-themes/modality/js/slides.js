var un=jQuery.noConflict();
un('.banner').unslider({
				arrows: true,
				fluid: true,
				dots: true,
				delay: php_vars.slideshowSpeed,
				speed: php_vars.animationSpeed,
				
			});