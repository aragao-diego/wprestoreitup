<?php
/**
 * The template for displaying the footer.
 *
 *
 * @package Personal Portfolio

 */
?>
<?php personalportfolio_wp_footer(); ?>

