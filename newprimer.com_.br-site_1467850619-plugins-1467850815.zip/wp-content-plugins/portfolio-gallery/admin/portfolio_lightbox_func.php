<?php
function showStyles($op_type = "0")
{
    $param_values = '';
    html_showStyles($param_values, $op_type);
}
?>